package com.example.chapter3.demo.animation;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.example.chapter3.demo.R;

public class LottieActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lottie);
    }
}
